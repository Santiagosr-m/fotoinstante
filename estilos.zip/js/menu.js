$(".submenu").click(function(){
$(this).children("ul").slideToggle();
})